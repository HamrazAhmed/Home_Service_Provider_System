package application;

import javafx.fxml.FXML;
import javafx.scene.layout.VBox;

public class plumbingController {

    @FXML
    private VBox electrianHolder;

}
